
        CREATE   PROCEDURE dbo.sp_invascan_add_geodata
        (
            @detectionId UNIQUEIDENTIFIER,
            @latitude FLOAT,
            @longitude FLOAT,
            @province NVARCHAR(500),
            @placename NVARCHAR(500) = NULL,
            @createdAt DATETIME = NULL
        )
        AS
        BEGIN
            SET NOCOUNT ON;
            INSERT INTO GeoData (Id, DetectionId, Latitude, Longitude, Province, Placename, CreatedAt)
            VALUES (NEWID(), @detectionId, @latitude, @longitude, @province, @placename, ISNULL(@createdAt, GETDATE()));
        END

        go

