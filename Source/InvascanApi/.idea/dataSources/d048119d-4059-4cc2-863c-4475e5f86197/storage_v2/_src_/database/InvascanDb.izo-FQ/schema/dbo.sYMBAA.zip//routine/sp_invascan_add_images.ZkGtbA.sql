
        CREATE   PROCEDURE dbo.sp_invascan_add_images
            @detectionId UNIQUEIDENTIFIER,
            @imageUrl NVARCHAR(1000),
            @imageData VARBINARY(MAX) = NULL
        AS
        BEGIN
            SET NOCOUNT ON;

            INSERT INTO Images (Id, DetectionId, ImageUrl, ImageData, UploadedAt)
            VALUES (NEWID(), @detectionId, @imageUrl, @imageData, GETDATE());
        END

        go

